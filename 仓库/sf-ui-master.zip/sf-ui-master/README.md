"scripts": {
    "dev": "pnpm -C play dev",
  },

pnpm -C 的意思是指定一个 工作目录，这里是指定 play目录，然后去执行该目录下面的 npm run dev 命令



功能列表：
Button
  - 已完成功能
    - 类型 type：default、primary、info、success、danger
    - 大小 size：large、small
    - 镂空 plain
    - 圆角胶囊 round
    - 圆形 circle
    - 图标 icon
      - 属性类型：<sf-button :icon="Delete" /> 需要引入图标库(图标库未完成)
      - 默认插槽类型：<sf-button> <icon></icon> </button>
      - 属性 + 插槽：<sf-button :icon="组件名"> <template #icon> ... </template> </button> 未完成
