const arr = ['Sem', 'Lolo', 'Kaquko']

function joinStrArray(names, separator, result = '') {
  const [current, ...rest] = names
  result = current
  if (rest.length > 0) {
    result = current + separator + joinStrArray(rest, separator)
  }
  return result
}

// const NamesComma = joinStrArray(names, ',')  // "Sem,Lolo,Kaquko"
// const NamesSpace = joinStrArray(names, ' ')  // "Sem Lolo Kaquko"
const namesStars = joinStrArray(arr, '⭐️') // "Sem⭐️Lolo⭐️Kaquko"
console.log(namesStars)
