type User = {
  id: number
  kind: string
}

function makeCustomer<T extends User>(u: T): T {
  return {
    ...u,
    id: u.id,
    kind: 'customer',
  }
}
function makeCustomer<T extends User>(u: T): User {
  return {
    id: u.id,
    kind: 'customer',
  }
}

function add(a: string, b: string): string
function add(a: number, b: number): number
function add(a: string | number, b: string | number): string | number {
  if (typeof a === 'string') {
    return a + ':' + b
  } else {
    return (a as number) + (b as number)
  }
}

add(2, 3)
// add('2', 3) error
add('2', '3')

type Foo = {
  a: number
  b?: string
  c: boolean
}
type SetOptional1<T, K extends keyof T> = Omit<T, K> & Partial<Pick<T, K>>
type SetOptional2<T, K extends keyof T> = Omit<T, K> & {
  [k in keyof Pick<T, K>]?: T[k]
}

type SetOptional3<T, K extends keyof T> = Simplify<
  Partial<Pick<T, K>> & Pick<T, Exclude<keyof T, K>>
>

type SomeOptional1 = SetOptional1<Foo, 'a' | 'b'>
type SomeOptional2 = SetOptional2<Foo, 'a' | 'b'>
type SomeOptional3 = SetOptional3<Foo, 'a' | 'b'>

type Simplify<T> = {
  [P in keyof T]: T[P]
}

const so1: SomeOptional1 = {
  b: '123',
  c: true,
}
const so2: SomeOptional2 = {
  b: '123',
  c: true,
}
const so3: SomeOptional3 = {
  b: '123',
  c: true,
}

interface Example {
  a: string
  b: string | number
  c: () => void
  d: {}
}

type ConditionalPick<V, T> = {
  [K in keyof V as V[K] extends T ? K : never]: T
}

type StringKeysOnly = ConditionalPick<Example, string>

let x = [0, 1, null, 'string']

// 定义一个工具类型 AppendArgument，为已有的函数类型增加指定类型的参数，新增的参数名是 x，将作为新函数类型的第一个参数。具体的使用示例如下所示：

type Fn = (a: number, b: string) => number
type AppendArgument1<F extends (...args: any) => any, A> = (
  x: A,
  ...args: Parameters<F>
) => ReturnType<F>

type AppendArgument2<F, T> = F extends (...args: infer Args) => infer Return
  ? (x: T, ...args: Args) => Return
  : never

type FinalFn1 = AppendArgument1<Fn, boolean>
type FinalFn2 = AppendArgument2<Fn, boolean>

// 定义一个 NativeFlat 工具类型，支持把数组类型拍平（扁平化）。具体的使用示例如下所示：
// type NaiveFlat<T extends any[]> = // 你的实现代码

type NaiveFlat1<T extends any[]> = {
  [P in keyof T]: T[P] extends any[] ? T[P][number] : T[P]
}[number]

// 测试用例：
type NaiveResult = NaiveFlat1<[['a'], ['b', 'c'], ['d']]>
// NaiveResult的结果： "a" | "b" | "c" | "d"

type Deep = [['a'], ['b', 'c'], [['d']], [[[['e']]]]]

type DeepFlat<T extends any[]> = {
  [K in keyof T]: T[K] extends any[] ? DeepFlat<T[K]> : T[K]
}[number]

type DeepTestResult = DeepFlat<Deep>

// 使用类型别名定义一个 EmptyObject 类型，使得该类型只允许空对象赋值：
type EmptyObject = {
  [K in PropertyKey]: never
}

// 测试用例
const shouldPass: EmptyObject = {} // 可以正常赋值
// 将出现编译错误
// const shouldFail: EmptyObject = { prop: 'TS' }

type SomeType = {
  prop: string
}

type Exclusive<T1, T2> = {
  [K in keyof T2]: K extends keyof T1 ? T2[K] : never
}

// 更改以下函数的类型定义，让它的参数只允许严格SomeType类型的值
function takeSomeTypeOnly<T extends SomeType>(x: Exclusive<SomeType, T>) {
  return x
}

// 测试用例：
const xxxx = { prop: 'a' }
takeSomeTypeOnly(xxxx) // 可以正常调用
const yyyy = { prop: 'a', addditionalProp: 'x' }
// takeSomeTypeOnly(yyyy) // 将出现编译错误

// 定义 NonEmptyArray 工具类型，用于确保数据非空数组。
// type NonEmptyArray<T> = // 你的实现代码
// type NonEmptyArray<T> = [T, ...T[]]
type NonEmptyArray<T> = T[] & { 0: T }

// const aa1: NonEmptyArray<string> = [] // 将出现编译错误
const aa2: NonEmptyArray<string> = ['Hello TS', '123'] // 非空数据，正常使用

// 定义一个 JoinStrArray 工具类型，用于根据指定的 Separator 分隔符，对字符串数组类型进行拼接。具体的使用示例如下所示：
// type JoinStrArray<Arr extends string[], Separator extends string, Result extends string = ""> = // 你的实现代码

type JoinStrArray<
  Arr extends string[],
  Separator extends string,
  Result extends string = ''
> = Arr extends [infer El, ...infer Rest]
  ? Rest extends string[]
    ? El extends string
      ? Result extends ''
        ? JoinStrArray<Rest, Separator, `${El}`>
        : JoinStrArray<Rest, Separator, `${Result}${Separator}${El}`>
      : `${Result}`
    : `${Result}`
  : `${Result}`

/* 
    [Lolo]   _  Result ===> Sem     JoinStrArray<[Lolo], _, Sem>

*/
// 测试用例
// type Names = ['Sem', 'Lolo', 'Kaquko']
// type Names = ['Sem', 'Lolo', 'Kaquko']
type Names = ['Sem', 'Lolo']
type NamesComma = JoinStrArray<Names, ','> // "Sem,Lolo,Kaquko"
type NamesSpace = JoinStrArray<Names, ' '> // "Sem Lolo Kaquko"
type NamesStars = JoinStrArray<Names, '⭐️'> // "Sem⭐️Lolo⭐️Kaquko"

// 10、实现一个 Trim 工具类型，用于对字符串字面量类型进行去空格处理。具体的使用示例如下所示：
// type Trim<V extends string> = // 你的实现代码
type TrimLeft<V extends string> = V extends ` ${infer R}` ? TrimLeft<R> : V
type TrimRight<V extends string> = V extends `${infer R} ` ? TrimRight<R> : V
type Trim<V extends string> = TrimLeft<TrimRight<V>>

// 测试用例
type trim = Trim<'  semlinker 1 '>
//=> 'semlinker'

// 11、实现一个 IsEqual 工具类型，用于比较两个类型是否相等。具体的使用示例如下所示：
// type IsEqual<A, B> = // 你的实现代码

type IsEqual<A, B> = A extends B ? (B extends A ? true : false) : false // 你的实现代码

// 测试用例
type E0 = IsEqual<1, 2> // false
type E1 = IsEqual<{ a: 1 }, { a: 1 }> // true
type E2 = IsEqual<[1], []> // false
type E3 = IsEqual<never, never> // false

// 12、实现一个 Head 工具类型，用于获取数组类型的第一个类型。具体的使用示例如下所示：
// type Head<T extends Array<any>> = // 你的实现代码

// type Head<T extends Array<any>> = T extends [] ? never : T[0]
// type Head<T extends Array<any>> = T['length'] extends 0 ? never : T[0]
type Head<T extends Array<any>> = T extends [infer F, ...any[]] ? F : never
// type Head<T extends Array<any>> = T extends [first: infer F, ...rest: any[]]
//   ? F
//   : never

// 测试用例
type H0 = Head<[]> // never
type H1 = Head<[1]> // 1
type H2 = Head<[3, 2]> // 3
type H3 = Head<['a', 'b', 'c']> // "a"
type H4 = Head<[undefined, 'b', 'c']> // undefined
type H5 = Head<[null, 'b', 'c']> // null

// 实现一个 Tail 工具类型，用于获取数组类型除了第一个类型外，剩余的类型。具体的使用示例如下所示：
// type Tail<T extends Array<any>> =  // 你的实现代码

type Tail<T extends Array<any>> = T extends [any, ...infer E] ? E : []

// 测试用例F
type T0 = Tail<[]> // []
type T00 = Tail<[1]> // []
type T1 = Tail<[1, 2]> // [2]
type T2 = Tail<[1, 2, 3, 4, 5]> // [2, 3, 4, 5]

// 14 实现一个 Unshift 工具类型，用于把指定类型 E 作为第一个元素添加到 T 数组类型中。具体的使用示例如下所示：
// type Unshift<T extends any[], E> =  // 你的实现代码
type Unshift<T extends any[], E> = [E, ...T]

// 测试用例
type Arr0 = Unshift<[], 1> // [1]
type Arr1 = Unshift<[1, 2, 3], 0> // [0, 1, 2, 3]

// 实现一个 Shift 工具类型，用于移除 T 数组类型中的第一个类型。具体的使用示例如下所示：
// type Shift<T extends any[]> = // 你的实现代码

type Shift<T extends any[]> = T extends [any, ...infer Rest] ? Rest : never

// 测试用例
type S0 = Shift<[1, 2, 3]>
type S1 = Shift<[string, number, boolean]>

// 16 实现一个 Push 工具类型，用于把指定类型 E 作为第最后一个元素添加到 T 数组类型中。具体的使用示例如下所示：
// type Push<T extends any[], V> = // 你的实现代码

type Push<T extends any[], V> = [...T, V]

// 测试用例
type Arr0 = Push<[], 1> // [1]
type Arr1 = Push<[1, 2, 3], 4> // [1, 2, 3, 4]

// 实现一个 Includes 工具类型，用于判断指定的类型 E 是否包含在 T 数组类型中。具体的使用示例如下所示：
// type Includes<T extends Array<any>, E> = // 你的实现代码

// type Includes<T extends Array<any>, E> = E extends T[number] ? true : false

// type UnionByArr<T extends Array<any>> = T extends [infer F, ...infer R]
//   ? F | UnionByArr<R>
//   : never
// type Includes<T extends Array<any>, E> = E extends UnionByArr<T> ? true : false

type GetArrayItemTypes<T extends Array<any>> = T extends Array<infer A>
  ? A
  : never
type Includes<T extends Array<any>, E> = E extends GetArrayItemTypes<T>
  ? true
  : false // 你的实现代码

type I0 = Includes<[], 1> // false
type I1 = Includes<[2, 2, 3, 1], 2> // true
type I2 = Includes<[2, 3, 3, 1], 1> // true

// 18 实现一个 UnionToIntersection 工具类型，用于把联合类型转换为交叉类型。具体的使用示例如下所示：
// type UnionToIntersection<U> = // 你的实现代码

type UnionToIntersection<U> = (
  U extends unknown ? (d: U) => void : never
) extends (m: infer I) => void
  ? I
  : never

type a<U> = U extends unknown ? (d: U) => void : never
type aaa1 = a<string | number> extends (i: infer I) => void ? I : false
type aaa2 = a<{ name: string } | { age: number }> extends (i: infer I) => void ? I : false

// 测试用例
type U0 = UnionToIntersection<string | number> // never
type U1 = UnionToIntersection<{ name: string } | { age: number }> // { name: string; } & { age: number; }

export {}
