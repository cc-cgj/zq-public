<template>
  <!-- 颜色 type: default、primary、info、success、danger、warning -->
  <div class="box" v-if="buttons.type">
    <sf-button @click="handleBtn" type="default">
      <span>Default</span>
    </sf-button>
    <sf-button type="primary">Primary</sf-button>
    <sf-button type="success">Success</sf-button>
    <sf-button type="info">info</sf-button>
    <sf-button type="warning">Warning</sf-button>
    <sf-button type="danger">Danger</sf-button>
  </div>
  <!-- 镂空 plain -->
  <div class="box" v-if="buttons.plain">
    <sf-button plain type="default">Default</sf-button>
    <sf-button plain type="primary">Primary</sf-button>
    <sf-button plain type="success">Success</sf-button>
    <sf-button plain type="info">info</sf-button>
    <sf-button plain type="warning">Warning</sf-button>
    <sf-button plain type="danger">Danger</sf-button>
  </div>
  <!-- 圆角 round -->
  <div class="box" v-if="buttons.round">
    <sf-button round type="default">Default</sf-button>
    <sf-button round type="primary">Primary</sf-button>
    <sf-button round type="success">Success</sf-button>
    <sf-button round type="info">info</sf-button>
    <sf-button round type="warning">Warning</sf-button>
    <sf-button round type="danger">Danger</sf-button>
  </div>
  <!-- 圆形 circle -->
  <div class="box" v-if="buttons.circle">
    <sf-button circle type="default">
      <sf-icon icon="#icon-pen_line"></sf-icon>
    </sf-button>
    <sf-button circle type="primary">
      <sf-icon icon="#icon-pen_line"></sf-icon>
    </sf-button>
    <sf-button circle type="success">
      <sf-icon icon="#icon-add_line"></sf-icon>
    </sf-button>
    <sf-button circle type="info">
      <sf-icon icon="#icon-alarm_2_line"></sf-icon>
    </sf-button>
    <sf-button circle type="warning">
      <sf-icon icon="#icon-alipay_pay_line"></sf-icon>
    </sf-button>
    <sf-button circle type="danger">
      <sf-icon icon="#icon-apple_line"></sf-icon>
    </sf-button>
  </div>
  <!-- 图标 icon -->
  <div class="box" v-if="buttons.icon">
    <!-- 纯图标 -->
    <sf-button :icon="Bookmark" />
    <sf-button :icon="Edit" type="primary" />
    <sf-button :icon="Upload" type="success" />
    <!-- 图标 + 文字 -->
    <sf-button type="info">
      <sf-icon class="sf-icon--right">
        <Edit></Edit>
      </sf-icon>
      编辑
    </sf-button>
    <sf-button type="info">
      编辑
      <sf-icon class="sf-icon--left">
        <Edit></Edit>
      </sf-icon>
    </sf-button>
    <sf-button type="warning" :icon="Upload">下载</sf-button>
    <sf-button type="danger">
      <sf-icon>
        <Edit></Edit>
      </sf-icon>
      IPhone
    </sf-button>
    <!-- 图标插槽式 -->
    <sf-button v-if="false">
      <template #icon>
        <span>图标</span>
      </template>
    </sf-button>
  </div>
  <!-- 大小 size: large、small -->
  <div class="box" v-if="buttons.size">
    <sf-button type="success">Default</sf-button>
    <sf-button size="large">large</sf-button>
    <sf-button size="small">small</sf-button>
    <sf-button>按钮</sf-button>
  </div>
  <div class="box" v-if="buttons.loading">
    <sf-button loading plain> Loading </sf-button>
    <sf-button
      :loading-icon="LoadingBubble"
      :loading="isLoading"
      type="primary"
    >
      Loading
    </sf-button>
    <sf-button :loading-icon="LoadingBubble" loading type="success">
      success
    </sf-button>
    <sf-button :loading-icon="LoadingBubble" loading type="info">
      info
    </sf-button>
    <sf-button :loading-icon="LoadingBubble" loading type="danger">
      danger
    </sf-button>
  </div>
  <div class="box" v-if="buttons.disabled">
    <sf-button disabled plain>disabled</sf-button>
    <sf-button disabled type="primary" plain>disabled</sf-button>
    <sf-button disabled type="success" plain>disabled</sf-button>
    <sf-button disabled type="info" plain>info</sf-button>
    <sf-button disabled type="danger" plain>disabled</sf-button>
    <sf-button disabled type="warning" plain>disabled</sf-button>
  </div>
</template>
<script setup lang="ts">
import { SfButton, SfIcon } from '@sf-ui/components'
import { Edit, Bookmark, Upload, LoadingBubble } from '@sf-ui/icons/src/index'

import { ref } from 'vue'

const buttons = {
  type: true,
  size: false,
  round: false,
  circle: false,
  plain: true,
  icon: false,
  loading: true,
  disabled: true,
}

const isLoading = ref<boolean>(true)

function handleBtn() {
  console.log('handleBtn')
  isLoading.value = !isLoading.value
}
</script>
<style scoped>
.box {
  display: flex;
  justify-content: space-around;
  align-items: flex-start;
  width: 500px;
  margin-bottom: 10px;
}
</style>
