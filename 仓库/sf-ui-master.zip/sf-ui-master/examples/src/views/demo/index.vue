<template>
  <sf-button>button</sf-button>
</template>

<script lang="ts" setup>
import type { PropType } from 'vue'
import { SfButton } from '@sf-ui/components'
export interface Person {
  name: string
  age: number
}

type Type = 'primary' | 'info'

const props = defineProps({
  author: {
    type: Object as PropType<Person>,
    default: () => ({
      name: 'zs',
      age: 123,
    }),
  },
  type: {
    type: String as PropType<Type>,
    default: 'primary',
  },
  size1: {
    type: (): Person => ({} as Person),
  },
})

function initProps(props?: any, defineValue?: any) {
  return {
    name: String as PropType<Type>,
    type: {
      type: String,
      default: '13',
    },
  }
}

console.log(initProps())

const p = {
  name: {
    type: String,
  },
}
const d = {
  name: 'zs',
}

// defineProps(initProps(p, d))

console.log(props)
</script>
