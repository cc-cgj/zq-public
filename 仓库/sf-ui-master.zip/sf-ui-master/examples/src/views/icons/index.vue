<template>
  <Edit></Edit>
</template>

<script lang="ts" setup>
import {} from '@sf-ui/components'
import { Edit } from '@sf-ui/icons/src/index'
</script>
