<template>
  <Button v-if="doms.button"></Button>
  <div v-if="doms.icons">
    <Icons></Icons>
  </div>
  <!-- <Demo :author="{ name: '', age: 12 }" :type="'primary'"></Demo> -->
</template>
<script setup lang="ts">
import Button from '@/views/button/index.vue'
import Demo from '@/views/demo/index.vue'

const doms = {
  button: true,
  icons: false,
}
</script>
<style scoped>
svg {
  width: 30px;
  height: 30px;
}
</style>
