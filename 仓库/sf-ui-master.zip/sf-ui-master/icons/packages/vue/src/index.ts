import type { App } from "vue";

import * as icons from "./components";

export default (app: App, { prefix = "SfIcon" }) => {
  for (const [key, comp] of Object.entries(icons)) {
    app.component(prefix + key, comp);
  }
};

export {
  icons
}

export * from './components'
