import type { Prop, PropType } from "vue";

import { defineComponent } from "vue";

export default defineComponent({
  props: {
    author: {
      type: Object as PropType<Person>,
    },
  },
});

interface Person {
  name: string;
  age: number;
}

// export function buildDefineProps<T>(
//   type: T,
//   defaultValue: {
//     [K in keyof T]?: T[K]
//   }
// ): T {
//   for (const key in type) {
//     const prop = type[key] as PrPropop<any>
//     prop.default = defaultValue[key]
//   }
//   return type
// }
