import { useGlobalConfig } from '../../hooks/useGlobalConfig'

export const defaultNamespace = 'sf'

const _bem = (
  namespace: string,
  block: string,
  blockSuffix: string,
  element: string,
  modifier: string
) => {
  let cls = `${namespace}-${block}`
  if (blockSuffix) {
    cls += `-${blockSuffix}`
  }
  if (modifier) {
    cls += `--${modifier}`
  }
  return cls
}

export function useNamespace(block: string) {
  const namespace = useGlobalConfig('namespace', defaultNamespace)
  const b = (blockSuffix = '') => _bem(namespace.value, block, blockSuffix, '', '')
  const m = (modifier?: string) => {
    return modifier ? _bem(namespace.value, block, '', '', modifier) : '' 
  }
  const is = (block: string, bool: boolean) => {
    if (bool) {
      return block;
    } else {
      return ''
    }
  }
  return {
    namespace,
    b,
    m,
    is
  }
}
