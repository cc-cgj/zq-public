const defaultPrefix = 'sf'

function getPrefix(prefix: string, customPrefix?: string): string {
  if (customPrefix) return customPrefix
  return prefix ? `${defaultPrefix}-${prefix}` : defaultPrefix
}

export function usePrefix(prefix: string, customPrefix?: string) {

  const prefixCls = getPrefix(prefix, customPrefix)

  return {
    prefixCls
  }}
