<template>
  <button
    :class="[
      ns.b(),
      ns.m(_type),
      ns.m(_size),
      ns.is('plain', isPlain),
      ns.is('round', isRound),
      ns.is('circle', isCircle),
      ns.is('loading', isLoading),
      ns.is('disabled', isDisabled),
    ]"
    :aria-disabled="isDisabled || isLoading"
    :disabled="isDisabled || isLoading"
    @click="handleClick"
  >
    <template v-if="isLoading">
      <sf-icon>
        <slot v-if="$slots.loading" name="loading"></slot>
        <component v-else :is="loadingIcon" />
      </sf-icon>
    </template>
    <sf-icon v-if="props.icon || $slots.icon">
      <component :is="icon" v-if="icon" />
      <slot v-else name="icon" />
    </sf-icon>
    <span v-if="$slots.default">
      <slot />
    </span>
  </button>
</template>
<script lang="ts" setup>
import type { Component } from "vue";
import type { ComponentSize } from "./../../constants/size";
import type { BtnType, ButtonNativeType } from "./types";

import { withDefaults, computed } from "vue";
import { useNamespace } from "@sf-ui/hooks";
import SfIcon from "../../icon";
import { Loading } from "@sf-ui/icons/src/index";

export interface ButtonProps {
  size?: ComponentSize;
  type?: BtnType;
  nativeType?: ButtonNativeType;
  plain?: boolean;
  round?: boolean;
  circle?: boolean;
  icon?: Component;
  loading?: boolean;
  loadingIcon?: Component;
  disabled?: boolean;
}

const emit = defineEmits(["click"]);

const props = withDefaults(defineProps<ButtonProps>(), {
  type: "",
  nativeType: "button",
  plain: false,
  round: false,
  circle: false,
  loading: false,
  disabled: false,
  loadingIcon: Loading
});

const ns = useNamespace("button");

const _type = computed(() => props.type || "");
const _size = computed(() => props.size || "");
const isPlain = computed(() => props.plain);
const isRound = computed(() => props.round);
const isCircle = computed(() => props.circle);
const isLoading = computed(() => props.loading);
const isDisabled = computed(() => props.disabled);

function handleClick(evt: MouseEvent) {
  if (props.nativeType === "reset") {
    //   form?.resetFields()
  }
  emit("click", evt);
}
</script>
<style lang="less" scoped>
@import "../style/index.less";
</style>
