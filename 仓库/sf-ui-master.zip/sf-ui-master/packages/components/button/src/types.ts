export type BtnType = 'default' | 'primary'| 'success'| 'warning'| 'danger'| 'info' | ''

export type ButtonNativeType = 'button' | 'submit' | 'reset'