import { withInstall } from '@sf-ui/utils'

import Button from './src/button.vue'

export const SfButton = withInstall(Button)

export default SfButton