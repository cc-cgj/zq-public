import { withInstall } from "@sf-ui/utils";
import icon from "./src/icon.vue";

export const SfIcon = withInstall(icon);

export default SfIcon;
