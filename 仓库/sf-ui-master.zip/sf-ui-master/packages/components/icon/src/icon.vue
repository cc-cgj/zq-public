<template>
  <i :class="getClass" :style="getStyle" v-bind="$attrs">
    <slot></slot>
  </i>
</template>
<script lang="ts" setup>
import { computed } from "vue";
import { useNamespace } from "@sf-ui/hooks/useNamespace";

const props = defineProps({
  size: {
    type: [String, Number],
    default: 14,
  },
  color: {
    type: String,
    default: "",
  },
});

const ns = useNamespace("icon");

const getClass = computed(() => {
  return [ns.b()];
});

/* eslint-disable */
const { color, size } = props;

const getStyle = computed(() => {
  return {
    color: color,
    fontSize: `${size}px`,
  };
});

</script>
<style lang="less">
@import "../../../design/index.less";

@icon-prefix-cls: ~'@{sf-prefix}-icon';

.@{icon-prefix-cls} {
  display: inline-flex;
  align-items: center;
  color: inherit;
  line-height: 1;
  vertical-align: middle;

  &--left {
    margin-left: 6px;
  }
  &--right {
    margin-right: 6px;
  }
}
</style>
