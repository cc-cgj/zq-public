<template>
  <svg :class="getClass" :style="getStyle" aria-hidden="true">
    <use :xlink:href="icon"></use>
  </svg>
</template>
<script lang="ts" setup>
import { computed } from "vue";
import { useNamespace } from "@sf-ui/hooks/useNamespace";
import "./iconfont/iconfont.js";

const props = defineProps({
  icon: {
    type: String,
    default: "",
  },
  size: {
    type: [String, Number],
    default: 14,
  },
  color: {
    type: String,
    default: "",
  },
});

const ns = useNamespace("icon");

const getClass = computed(() => {
  return ["svg-icon", ns.b()];
});

/* eslint-disable */
const { color, size } = props;

const getStyle = computed(() => {
  return {
    color: color,
    fontSize: `${size}px`
  };
});
</script>
<style lang="less">
@import "../../../design/index.less";
.svg-icon {
  width: 1em;
  height: 1em;
  vertical-align: -0.15em;
  fill: currentColor;
  overflow: hidden;
  color: inherit;
}
</style>
