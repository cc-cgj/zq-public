# The Stand-Alone App

This is useful for working on a React Native app *without* debugging in
chrome. The js runs in jscore, and the devtools talk to it through a
websocket.

The shell is located in `packages/react-devtools` in this repository.
